/**
 * Created by semianchuk on 07.05.16.
 */
var data={}

data.domain = 'http://gport-map.tk/'
data.domain = 'http://localhost:8080/'
data.be = 'http://localhost:8080/'

module.exports = data;
